
import os
import time
import fitz
import re
from datetime import datetime

from utils import MaiAgentHelper
from config import WEB_CHAT_ID, API_KEY, API_BASE_URL, STORAGE_URL, CHATBOT_ID
from pdf2image import convert_from_path, convert_from_bytes


API_KEY = API_KEY
CHATBOT_ID = CHATBOT_ID
FILE_PATH = "output/CA0001.txt"

assert API_KEY != '<your-api-key>', 'Please set your API key'
assert CHATBOT_ID != '<your-chatbot-id>', 'Please set your chatbot id'
assert FILE_PATH != '<your-file-path>', 'Please set your file path'

PDF_PATH = "/Users/luowen/Downloads/maiagent-project-main/2024_1205中經院出版品/"
LOG_FILE = "./progress_pdf_txt.log"

def upload_to_maiagent(file_path):
    maiagent_helper = MaiAgentHelper(
        api_key=API_KEY,
        base_url='http://ici-rag.nccu.edu.tw:443/api/v1/',
        storage_url='http://ici-rag.nccu.edu.tw:9000/magt-bkt'
    )

    file_size = os.path.getsize(file_path)

    # Check if file size is greater than 100MB
    if file_size > 100 * 1024 * 1024:
        log_message("File is larger than 100MB: " + file_path)
    else:
        response = maiagent_helper.upload_knowledge_file(CHATBOT_ID, file_path)

    # response = maiagent_helper.upload_knowledge_file(CHATBOT_ID, file_path)
    # print(response)

def log_message(message):
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}")

def extract_text_from_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    all_text = ""
    for page_num, page in enumerate(doc, start=1):
        text = page.get_text()
        all_text += f"\n\n--- Page {page_num} ---\n{text}"
    doc.close()
    return all_text


def main():
    
    pdf_files = [os.path.join(root, file) for root, dirs, files in os.walk(PDF_PATH) for file in files if file.endswith('.pdf') or file.endswith('.PDF')]

    for pdf_path in pdf_files: 

        with open(LOG_FILE, "r", encoding="utf-8") as f:
            done_list = [line.strip() for line in f if line.strip()]

        if pdf_path in done_list:
            time.sleep(0.1)
            log_message("FILE EXISTS: " + pdf_path)

        else:

            txt = extract_text_from_pdf(pdf_path)
            if len(txt) > 10000:

                upload_to_maiagent(pdf_path)
                log_message("UPLOAD: " + pdf_path)
                time.sleep(3)

                with open(LOG_FILE, "a") as file:
                    file.write(pdf_path + "\n")







if __name__ == '__main__':
    main()
