import os
import time
from datetime import datetime

from utils import MaiAgentHelper
from config import API_KEY, CHATBOT_ID



API_KEY = API_KEY
CHATBOT_ID = CHATBOT_ID
FILE_PATH = 'DP0001.txt'

assert API_KEY != '<your-api-key>', 'Please set your API key'
assert CHATBOT_ID != '<your-chatbot-id>', 'Please set your chatbot id'
assert FILE_PATH != '<your-file-path>', 'Please set your file path'


WORD_PATH = "/Users/luowen/Downloads/maiagent-project-main/2024_1205中經院出版品/"
LOG_FILE = "./progress_word.log"


def upload_to_maiagent(file_path):
    maiagent_helper = MaiAgentHelper(
        api_key=API_KEY,
        base_url='http://140.119.63.98:443/api/v1/',
        storage_url='https://nccu-ici-rag-minio.jp.ngrok.io/magt-bkt'
    )

    try:
        response = maiagent_helper.upload_knowledge_file(CHATBOT_ID, file_path)
        print(response.text)
    except Exception as e:
        print(e)

def log_message(message):
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}") 


def main():
    
    word_files = [os.path.join(root, file) for root, dirs, files in os.walk(WORD_PATH) for file in files if file.endswith('.doc') or file.endswith('.DOC')
                   or file.endswith('.docx')  or file.endswith('.DOCX')]
    
    for word_path in word_files:

        # Read lines into a list
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            done_list = [line.strip() for line in f if line.strip()]

        if word_path in done_list:
            time.sleep(0.3)
            log_message("FILE EXISTS: " + word_path)

        else:
            upload_to_maiagent(word_path)

            log_message("UPLOAD: " + word_path)

            time.sleep(5)

            with open(LOG_FILE, "a") as file:
                file.write(word_path + "\n")









if __name__ == '__main__':
    main()