import os
import requests
import json
import base64
import time
from datetime import datetime

from utils import MaiAgentHelper
from config import WEB_CHAT_ID, API_KEY, API_BASE_URL, STORAGE_URL, CHATBOT_ID
from pdf2image import convert_from_path, convert_from_bytes


API_KEY = API_KEY
CHATBOT_ID = CHATBOT_ID
FILE_PATH = "output/CA0001.txt"

assert API_KEY != '<your-api-key>', 'Please set your API key'
assert CHATBOT_ID != '<your-chatbot-id>', 'Please set your chatbot id'
assert FILE_PATH != '<your-file-path>', 'Please set your file path'

PDF_PATH = "/Users/luowen/Downloads/maiagent-project-main/2024_1205中經院出版品/"
# PNG_PATH = "/Users/luowen/Downloads/maiagent-project-main/png/"
# TXT_PATH = "/Users/luowen/Downloads/maiagent-project-main/txt/"
PNG_PATH = "./png/"
TXT_PATH = "./txt/"
LOG_FILE = "./progress_pdf_r.log"



def log_message(message):
    print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')} - {message}")

def png_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode("utf-8")
    return encoded_string


def ocr (image_path):

    log_message("OCR: " + image_path)

    base64_string = png_to_base64(image_path)

    # Define the API endpoint
    url = "http://140.119.63.98:11435/api/generate"

    # Define the payload
    payload = {
        "model": "gemma3:27b",
        "prompt": "你是一個OCR專家，請幫我截取圖片中的繁體中文。只需要輸出文字",
        "stream": False,
        "images": [base64_string]
    }

    # Set headers
    headers = {
        "Content-Type": "application/json"
    }

    try:
        # Make the request
        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=300)
        log_message("OCR DONE")
        return response.json()['response']

    except requests.exceptions.Timeout:
        log_message("OCR Timeout")
        return ""

    
def upload_to_maiagent(file_path):
    maiagent_helper = MaiAgentHelper(
        api_key=API_KEY,
        base_url='http://140.119.63.98:443/api/v1/',
        storage_url='https://nccu-ici-rag-minio.jp.ngrok.io/magt-bkt'
    )

    response = maiagent_helper.upload_knowledge_file(CHATBOT_ID, file_path)
    # print(response)



def main():
    
    pdf_files = [os.path.join(root, file) for root, dirs, files in os.walk(PDF_PATH) for file in files if file.endswith('.pdf') or file.endswith('.PDF')]
    pdf_files.reverse()

    for pdf_path in pdf_files: 
        # print(pdf_path)
        # log_message(pdf_path)

        with open(LOG_FILE, "r", encoding="utf-8") as f:
            done_list = [line.strip() for line in f if line.strip()]

        if pdf_path in done_list:
            time.sleep(0.1)
            log_message("FILE EXISTS: " + pdf_path)

        else:
            time.sleep(10)
            relative_path = os.path.relpath(pdf_path, PDF_PATH)
            log_message("PROCESSING:" + relative_path)

            # TXT handler
            txt_relative_path = os.path.splitext(relative_path)[0] + ".txt"
            txt_path = os.path.join(TXT_PATH, txt_relative_path)
            os.makedirs(os.path.dirname(txt_path), exist_ok=True)
            # print(txt_path)

            # PNG Handler
            png_relative_path = os.path.splitext(relative_path)[0] + ".png"
            png_path = os.path.join(PNG_PATH, txt_relative_path)
            os.makedirs(os.path.dirname(png_path), exist_ok=True)
            # print(png_path)
            
            # Convert PDF to a list of images (one image per page)
            images = convert_from_bytes(open(pdf_path, 'rb').read())

            # Save each image as a PNG file
            for i, image in enumerate(images):

                filename = png_path + "_page_{:03d}.png".format(i)
                image.save(filename, 'PNG')
                txt = ocr(filename)

                with open(txt_path, "a") as file:
                    file.write(txt + "\n")

            #upload_to_maiagent(txt_path)

            with open(LOG_FILE, "a") as file:
                file.write(pdf_path + "\n")


        



if __name__ == '__main__':
    main()
